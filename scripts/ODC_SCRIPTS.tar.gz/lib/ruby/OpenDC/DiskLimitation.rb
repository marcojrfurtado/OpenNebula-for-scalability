#!/usr/bin/ruby

module OpenDC


    class DiskLimitation


        STRESS_COMMAND="/usr/bin/stress -d  "
        KILL_STRESS_COMMAND="/usr/bin/killall -9 stress "


        DEFAULT_REMOTE_DIR="~"

        Virsh_info = Struct.new(:quota,:period,:shares)


        def self.set_concurrent_workers(host,amount)

            cmd =  STRESS_COMMAND + amount.to_s + " "


            ret = BackgroundRemotesCommand.run(cmd,host.name,DEFAULT_REMOTE_DIR)

            if ( exit_code(ret.stderr) == 0 )
                puts "Disk has been succesfully stressed."
            else
                puts ret.stderr
                exit -1
            end

        end

        def self.end_concurrent_workers(host)


            cmd = KILL_STRESS_COMMAND

            ret = RemotesCommand.run(cmd,host.name,DEFAULT_REMOTE_DIR)

            if ( exit_code(ret.stderr) == 0 )
                OpenDC.log "Stress has been finalized."
            else
                puts ret.stderr
                exit -1
            end

        end

        private



        def self.exit_code(cmd)
            cmd[/ExitCode: ([0-9]+)/,1].to_i
        end

    end

end

