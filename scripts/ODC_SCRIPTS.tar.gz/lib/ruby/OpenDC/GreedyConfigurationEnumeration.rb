#!/usr/bin/ruby

require 'thread'

module OpenDC

    class GreedyConfigurationEnumeration


        # Resource amount that we propose to shift at each iteration
        DELTA=0.05

        # Minimum cost difference
        MIN_DIFF = 0

        DEFAULT_CPU_SHARES=1024


        # Allocation limits. Should remain between 0 and 1
        UPPER_LIMIT=0.9
        LOWER_LIMIT=0.1


        attr_reader :search_thread


        def initialize(host)

            OpenDC.log "Greedy search created for host #{host.id}"

            # Defines when a search can be stopped
            @finalize = false

            @host = host

            @client = Client.new

            #@cost_estimator = CostEstimator.new(@host)


            # Avoids concurrent writes/reads to @finalize
            @finalize_semaphore = Mutex.new

            @helpers = Hash.new

         #   begin
         #       @cost_estimate = LinearRegression.new(VMDIR+"/#{host.id}"+"/cpu_operator_cost.dat")
         #   rescue
         #       OpenDC.log_error "Data file not found. Exiting "
         #       exit -1
         #   end
        end

        def run_thread(hps=nil)
            if hps
                @helpers = hps
            end


#            @cost_estimator.total_allocation=DEFAULT_CPU_SHARES*@helpers.size

            @search_thread = Thread.new {
                run(hps)
                lg = LoadGenerator.new(self,@helpers)
                lg.run
            }

        end

        def run(hps=nil,keep_cost_model=true)


            if hps
                @helpers = hps
            end



            OpenDC.log "Greedy Search starting for\n\t#{@helpers.size} vms."

            empty_helpers = @helpers.detect{ |key,hp| hp.workload_array.size == 0 }
            # If there are empty helpers, we stop searching and return the cureent helpers.
            if empty_helpers

                OpenDC.log "Greedy Search: No more workloads for #{empty_helpers.size} VM(s). Returning unmodified helpers."
                return @helpers

            end

            if hps and keep_cost_model
                @helpers.each{|key,search_helper|

                    # Run cost estimates with a possible updated cost estimator
                    workload = search_helper.workload_array.first
                    search_helper.current[:cost]=search_helper.cost_estimator.estimate(workload,search_helper.current[:allocation],search_helper.db_helper)

                }
            else
                @helpers.each{|key,search_helper|

                    search_helper.cost_estimator.total_allocation=DEFAULT_CPU_SHARES*@helpers.size

                    workload = search_helper.workload_array.first
                    search_helper.current[:cost]=search_helper.cost_estimator.estimate(workload,DEFAULT_CPU_SHARES,search_helper.db_helper)
                    search_helper.current[:allocation]=DEFAULT_CPU_SHARES

                    # Set default allocation
                    CPULimitation.set_softlimit(search_helper.vm,@host,search_helper.current[:allocation])

                }
            end
            message = "Initial allocation:"
            @helpers.each {|key,hp|
                  message<<"\n\tVM #{hp.vm.id}: Allocation #{hp.current[:allocation]}, Cost #{hp.current[:cost]}"
            }
            OpenDC.log message


            if SEARCH_ENABLED
                done = false
                until done



                    max_gain=0
                    min_loss=nil
                    increased=Hash.new
                    decreased=Hash.new
                    cost_res_increased = cost_res_decreased = 0
                    max_cost = min_cost = 0


                    shift=( DELTA*(DEFAULT_CPU_SHARES*@helpers.size) ).to_i

                    @helpers.each{|key,search_helper|


                        unless  (1..(search_helper.cost_estimator.total_allocation-1)).include?(search_helper.current[:allocation] )

                            message="Resource allocation has limit a boundary. Tried to allocate #{search_helper.current[:allocation]} to VM #{search_helper.vm.id}."
                            OpenDC.log_error message
                            raise OpenDC::Error.new message

                        end


                        workload = search_helper.workload_array.first


                        if ( (search_helper.current[:allocation] + shift ) < (search_helper.cost_estimator.total_allocation * UPPER_LIMIT )    )
                            cost_res_increased = search_helper.cost_estimator.estimate(workload, search_helper.current[:allocation] + shift, search_helper.db_helper )

                            if ( ( search_helper.current[:cost] - cost_res_increased ) > max_gain  )
                                max_gain = search_helper.current[:cost] - cost_res_increased
                                increased[:vid] = search_helper.vm.id.to_s
                                increased[:amount] = cost_res_increased
                            end
                        end



                        if ( (search_helper.current[:allocation] - shift ) > (search_helper.cost_estimator.total_allocation * LOWER_LIMIT )   )

                            cost_res_decreased =  search_helper.cost_estimator.estimate(workload, search_helper.current[:allocation] - shift, search_helper.db_helper )

                            if (  (min_loss.nil?) or ( cost_res_decreased - search_helper.current[:cost]  ) < min_loss   )

                                min_loss = cost_res_decreased - search_helper.current[:cost]
                                decreased[:vid] = search_helper.vm.id.to_s
                                decreased[:amount] = cost_res_decreased

                            end
                        end

                        if ( cost_res_decreased < 0 or cost_res_increased < 0 )
                            done = true
                            break
                        end


                    }

                    if ( decreased[:vid].nil? or decreased[:vid].nil? )
                        OpenDC.log "Greedy Search: Didn't find a VM to have its resources reallocated."
                        done = true
                    end

                    if (  ( !done ) && ( decreased[:vid] != increased[:vid] )  && (  max_gain - min_loss > MIN_DIFF   )  )

#                        puts "res #{max_gain} : #{min_loss}"
                        message = "Greedy Search: Resource reallocation
                        \n\tCurrent Allocation:
                        \t\tVM #{increased[:vid]}
                        \t\t\tAllocation: #{@helpers[increased[:vid]].current[:allocation]}
                        \t\t\tCost: #{@helpers[increased[:vid]].current[:cost]}
                        \t\tVM #{decreased[:vid]}
                        \t\t\tAllocation: #{@helpers[decreased[:vid]].current[:allocation]}
                        \t\t\tCost: #{@helpers[decreased[:vid]].current[:cost]}\n"

                        # VM to have resources increased
                        @helpers[increased[:vid]].current[:allocation]+=shift
                        @helpers[increased[:vid]].current[:cost] = increased[:amount]

                        # VM to have resources decreased
                        @helpers[decreased[:vid]].current[:allocation]-=shift
                        @helpers[decreased[:vid]].current[:cost] = decreased[:amount]


                        message<<"\tNew Allocation:
                        \t\tVM #{increased[:vid]}
                        \t\t\tAllocation: #{@helpers[increased[:vid]].current[:allocation]}
                        \t\t\tCost: #{@helpers[increased[:vid]].current[:cost]}
                        \t\tVM #{decreased[:vid]}
                        \t\t\tAllocation: #{@helpers[decreased[:vid]].current[:allocation]}
                        \t\t\tCost: #{@helpers[decreased[:vid]].current[:cost]}\n"

                        OpenDC.log message


                    else

                        message = "Final allocation:"
                        @helpers.each {|key,hp|
                            message<<"\n\tVM #{hp.vm.id}: Allocation #{hp.current[:allocation]}, Cost #{hp.current[:cost]}"
                        }
                        OpenDC.log message

                        done = true

                    end

                    @finalize_semaphore.synchronize {
                        done|=@finalize
                    }
                end
                OpenDC.log "Greedy Search stopping."
            else
                OpenDC.log "Greedy Search disabled."
            end

            # Apply the values we obatined during the search for the parameters and the allocation
            @helpers.each{|key,hp|

                OpenDC.log "Greedy Search: Applying VM and DBMS parameters found during the search."
                CPULimitation.set_softlimit(hp.vm,@host,hp.current[:allocation])
                hp.cost_estimator.set_parameters(hp.current[:allocation].to_f/hp.cost_estimator.total_allocation)

            }

            @helpers

        end

        def add_workload(wk)


            if @helpers[wk.vm_id]
                @helpers[wk.vm_id].workload_array+=wk.workload_array
                @helpers[wk.vm_id].db_helper||= DatabaseHelper.new(@helpers[wk.vm_id].vm,5432,wk.dbname,wk.username,wk.userpassword)
            else
                message = "Workload dispatched to a non-existent VM."
                OpenDC.log_error message
                raise Error.new message
            end


            vm_left = @helpers.detect {|key,helper|
                # First position: key, last: value
                helper.workload_array.size == 0
            }

            OpenDC.log "Greedy Search: Workload was added for VM #{wk.vm_id}."


            if (  !vm_left and !thread_status and @helpers.size > 1 )
                OpenDC.log "Greedy Search was activated for host #{@host.id}.\n\t#{@helpers.size} VMs were added."
                self.run_thread
            end

        end

        def add_vm(vm_id)
            unless @helpers[vm_id] or thread_status
                @helpers[vm_id] = SearchHelper.new
                @helpers[vm_id].vm = VirtualMachine.new_with_id(vm_id,@client)
                @helpers[vm_id].vm.info
                @helpers[vm_id].workload_array=[]
                @helpers[vm_id].current=Hash.new
                @helpers[vm_id].cost_estimator=CostEstimator.new(@host)
                @helpers[vm_id].cost_estimator.history=true
            end
            if thread_status
                OpenDC.log_error "VM added while search was still running. You may want to finalize it."
            end
            OpenDC.log "Greedy Search: VM #{vm_id} was added."
            vm_id
        end



        def finalize=(val)
            @finalize_semaphore.synchronize {
                @finalize = val
            }
        end

        private

        def thread_status
            @search_thread and @search_thread.status == "run"
        end

    end
end
