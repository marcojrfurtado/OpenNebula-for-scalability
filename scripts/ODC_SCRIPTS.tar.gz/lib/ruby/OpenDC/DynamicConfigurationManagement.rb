#!/usr/bin/ruby

#require 'thread'
#require 'observer'

module OpenDC

    class DynamicConfigurationManagement

        attr_accessor :enabled, :main_thread

        include Observable

        THETA=0.15
        # Period to check for changes in the workloads
        MONITORING_PERIOD=4

        class WorkloadMonitorHelper <
            Struct.new(:workload_processor,:cost_estimator,:estimator_lock)
        end


        def initialize(load_generator)

            @lg=load_generator
#            @dcm_helpers=Hash.new


            @main_thread=nil

            @enabled=true
            run
        end



        def update_estimator(key,cost_estimator)
            @dcm_helpers[key].estimator_lock.synchronize {

                @dcm_helpers[key].cost_estimator=cost_estimator
            }
        end


        def run

            OpenDC.log "Dynamic Configuration Management: Starting"
            @main_thread = Thread.new {

                while @enabled
                    sleep MONITORING_PERIOD

                    if !@enabled
                        OpenDC.log "Dynamic Configuration Management: Monitor has been disabled. Exiting."
                        break
                    end
                    OpenDC.log "Dynamic Configuration Management: Monitoring period has ended."
                    result = @lg.load_snapshot

                    # The load generator will return nil if load estimatives aren't trustworthy (i.e. haven't been refined at least once)
                    unless result
                        OpenDC.log "Dynamic Configuration Management: No snapshot returned."
                        next
                    end

                    OpenDC.log "Dynamic Configuration Management: Workload information has been retrieved"
                    hp_threads=[]
                    restart_search_hash=Hash.new
                    #puts "inspect:"
                    #puts result.inspect

                    result.each { |vm|

                        key = vm[0]
                        log_message="Dynamic Configuration Management: Monitoring workload for VM #{key}"



                        # Get the average estimated and the actual cost of running a workload query.
                        # Then find the difference
                        per_query_avg = vm[1]
                        per_query_est = vm[2]

                        if per_query_avg and per_query_est
                            diff = (per_query_avg - per_query_est).abs

                            relative_change=diff/per_query_avg

                            restart_search_hash[key]=(relative_change>THETA)?true:false

                            log_message<<"\n\tEstimated cost per query: #{per_query_est}"
                            log_message<<"\n\tActual cost per query: #{per_query_avg}"
                            log_message<<"\n\tRelative Change: #{relative_change}"
                            log_message<<"\n\tThreshold: #{THETA}"
                            log_message<<"\n\tRestart Search: #{restart_search_hash[key]}"
                        else
                            log_message<<"\n\tMissing information about workload"
                            restart_search_hash[key]=false
                        end


                        OpenDC.log log_message
                    }


                    restart_search = restart_search_hash.inject { |res,(key,value)| res or value  }
                    if restart_search
                        OpenDC.log "Dynamic Configuration Management: One or more workloads have changed beyond a limit. Notifying the Load Generator."
                        notify_observers(true)
                    else
                        OpenDC.log "Dynamic Configuration Management: No changes in the workloads have been detected at this time."
                    end
                end
                OpenDC.log "Dynamic Configuration Management: Finalizing"
            }


        end

    end
end
