#!/usr/bin/ruby

require_relative 'PostgreSQL/QueryProcessorHelper'
require_relative 'PostgreSQL/WorkloadProcessorHelper'
require_relative 'PostgreSQL/ParameterSetter'
require 'pg'

module OpenDC


    module PostgreSQL


        DEFAULT_HOST = "127.0.0.1"
	    DEFAULT_PORT = 5432
	    DEFAULT_DBNAME = "calibration"
	    DEFAULT_DBUSER = "calibrate"
	    DEFAULT_DBPASSWORD = "calibrate"
	#    DEFAULT_QUERY_FOLDER = "./queries"
        #

	    FILE_MAX_CONTENT = 90000


        module PostgreSQLCalibration
            def calibration_parameters
                   ["cpu_operator_cost"]
            end
        end

        # This class represents the results obtained after an EXPLAIN ANALZYZE query execution.
        # In OpenDC, only inherent data is filtered.
        class QueryPlanResult <
            Struct::new(:rows, :actual_total_cost, :nominal_total_cost, :pages_hit, :pages_read)
        end

        class DBClient

            def initialize( hostaddr = DEFAULT_HOST, port = DEFAULT_PORT, dbname = DEFAULT_DBNAME, dbuser = DEFAULT_DBUSER, dbpassword = DEFAULT_DBPASSWORD)


        		@conn = PG.connect( :hostaddr => hostaddr, :dbname => dbname, :port => port, :user => dbuser, :password => dbpassword )

    	    	unless @conn
	    	    	raise Error.new "Couldn't connect to specified database"
        		end

                @conn
    	    end

            def run_query(query_text)
                @conn.exec(query_text)
            end

            def run_query_file(file_path)
    		    fp = File.open(file_path,"r")

    	    	unless fp
	    	        Error "Unable to open file #{query_file}."
        		end

                run_query(fp.sysread(FILE_MAX_CONTENT))

            end

        end


    end
end
