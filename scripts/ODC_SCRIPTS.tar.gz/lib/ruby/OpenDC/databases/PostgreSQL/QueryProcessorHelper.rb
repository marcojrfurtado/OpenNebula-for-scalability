#!/usr/bin/ruby

module OpenDC
module PostgreSQL
	class QueryProcessorHelper


        attr_accessor :client

        def initialize( client, hid=nil )
            @client = client
            @factor = nil
            @hid = hid
        end

        def process_file(query_file, run = true, show_buffers = false)

	    	fp = File.open(query_file,"r")
            unless fp
		        Error "Unable to open file #{query_file}."
    		end

            file_content = fp.sysread(FILE_MAX_CONTENT)
            self.process(file_content,run,show_buffers)
        end

	    def process(query, run = true, show_buffers = false)



	    	formatted_result_set = Array.new
            if run
        		result = run_analyze_query(query,show_buffers)
            else
                result = run_explain_query(query)
            end
    		result.each{ |tuple|
                formatted_result = QueryPlanResult.new

                if ( describe_buffers(tuple['QUERY PLAN']) )

                    hit = get_buffers_hit(tuple['QUERY PLAN'])
                    read = get_buffers_read(tuple['QUERY PLAN'])

                    if formatted_result_set.size > 0
                        formatted_result_set.last.pages_read = read
                        formatted_result_set.last.pages_hit = hit
                    end
                    next
                end

                new_cost = get_actual_total_cost(tuple['QUERY PLAN'])
                new_nominal_cost = get_nominal_total_cost(tuple['QUERY PLAN'])
                num_rows = get_total_rows(tuple['QUERY PLAN'])
                formatted_result.rows = num_rows
                formatted_result.actual_total_cost = new_cost
                formatted_result.nominal_total_cost = new_nominal_cost
    		    formatted_result_set << formatted_result
		    }
    		formatted_result_set
	    end

        def get_runtime_file(query_file)

	    	fp = File.open(query_file,"r")
            unless fp
		        Error "Unable to open file #{query_file}."
    		end

            file_content = fp.sysread(FILE_MAX_CONTENT)
            self.get_runtime(file_content)
        end

        def get_runtime(query)

            t1 = Time.now
            @client.run_query(query)
            t2= Time.now

            (t2 - t1) * 1000.0
        end

        def normalize_cost(nominal)
            @factor  = get_seq_page_scan_value() if @factor.nil?
            nominal * @factor
        end

	private
	    def run_analyze_query(raw_query, show_buffers=false )

            if show_buffers
                explain= "EXPLAIN (ANALYZE,BUFFERS) "
            else
                explain= "EXPLAIN ANALYZE "
            end
            query_text = explain+raw_query;
    		@client.run_query(query_text)
	    end


        def run_explain_query(raw_query)
            query_text = "EXPLAIN "+raw_query;
            @client.run_query(query_text)
        end

	    def get_actual_total_cost(tuple)
    		begin
                match = tuple[/actual time=([0-9]*\.[0-9]+|[0-9]+)\.\.([0-9]*\.[0-9]+|[0-9]+)/, 2]
            rescue Exception => e
                puts e.backtrace
            end
		    if match
		    match.to_f
    		else
	    	    nil
		    end
	    end

        def get_nominal_total_cost(tuple)
    		match = tuple[/cost=([0-9]*\.[0-9]+|[0-9]+)\.\.([0-9]*\.[0-9]+|[0-9]+)/, 2]
		    if match
		    match.to_f
    		else
	    	    nil
		    end
        end

        def get_total_rows(tuple)
            match= tuple[/rows=([0-9]*)/,1]
            if match
                match.to_i
            else
                nil
            end
        end

        def get_cpu_tuple_cost()
            dir = OPENDC_LOCATION + "/queries/SHOW_cpu_tuple_cost.sql"
		    fp = File.open(dir)

    		unless fp
	    	    raise Error.new "Unable to open file #{query_file}."
                exit -1
    		end

	    	formatted_result_set = Array.new
		    result = @client.run_query(fp.sysread(FILE_MAX_CONTENT))
            result.values.first.first.to_f
        end

        def describe_buffers(text)
            match = nil
            match = text[/(Buffers)/] if text
            match
        end

        def get_buffers_hit(text)
            match = text[/hit=([0-9]*)/,1]
            match.to_i if match
        end

        def get_buffers_read(text)
            match = text[/read=([0-9]*)/,1]
            match.to_i if match
        end

        def get_seq_page_scan_value()
            fp = File.open(VMDIR + "/calibration_results/" + @hid.to_s + "/seq_page_scan.dat" )
            unless fp
                message = "Unable to open seq_page_scan file related to host #{@hid}."
                OpenDC.log_error message
                raise Error.new message
            end
            fp.sysread(FILE_MAX_CONTENT).to_f
        end

	end

end
end

#cal = Calibration.new
#puts cal.get_costs("./queries/seq_scan.sql")
#cal.get_costs("./queries/aggregate_seq_scan.sql")

