
#!/usr/bin/ruby

module OpenDC
    module PostgreSQL
        class ParameterSetter


            attr_accessor :client

            def initialize( client )
                @client = client
            end

            def set(parameter, value)
                query = "SET " + parameter + "=" + value.to_s + ";"

                @client.run_query(query)
            end

            def reset(parameter)
                query= "RESET " + parameter + ";"
                result = @client.run_query(query)
            end

            def get_num(parameter)
                query "SHOW " + parameter + ";"

		        result = @client.run_query(query)
                result.values.first.first.to_f
            end

        end

    end
end


