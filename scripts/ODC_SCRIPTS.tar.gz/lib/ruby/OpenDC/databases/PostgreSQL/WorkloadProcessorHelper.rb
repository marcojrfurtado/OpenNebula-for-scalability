#!/usr/bin/ruby

require 'thread'

module OpenDC
    module PostgreSQL

        class WorkloadProcessorHelper


            LIMIT_HISTORY=2

            attr_accessor :history

            def initialize( qp )
                @qp = qp
                @cost_history=[]
                @history_lock=Mutex.new
                @history=true
            end


            def calculate_cost_file( workload_file, run=false)
                fp = File.open(workload_file,"r")

                queries = split_workload fp.sysread(FILE_MAX_CONTENT)
                calculate_cost( queries,run)
            end

            # Calculates an average cost per query
            def calculate_cost( queries, run=false, analyze=false )

                # Split queries as strings.
                unless queries.is_a? Array
                     queries = split_workload(queries)
                end



                costs = []
                queries.each{|query|
                    if run and !analyze
                        new_cost = @qp.get_runtime(query)
                    else
                        new_cost = @qp.process(query,run).first
                    end
                    costs << new_cost
                    if @history and run
                        @history_lock.synchronize {
                            @cost_history << new_cost
                            if @cost_history.size > LIMIT_HISTORY
                                OpenDC.log "Workload Processor: Cost history array has hit a limit. Deleting last record."
                                @cost_history.pop
                            end
                        }
                    end
                }

                sum = 0.0
                if run
                    costs.each{ |el|
                        if ( analyze )
                            sum+=el.actual_total_cost
                        else
                            sum+=el
                        end
                    }
                    return sum
                else
                    costs.each{ |el| sum+=el.nominal_total_cost }

                    return @qp.normalize_cost(sum)
                end
            end

            def split_workload(queries)
                queries.chomp.split(';')
            end

            def history_average
                ret=0.0
                @history_lock.synchronize {
                    if @cost_history.size > 0
                        ret = @cost_history.inject{|sum,el|sum+el}.to_f / @cost_history.size
                        @cost_history=[]
                    end
                }
           #     puts ret
                ret
            end



        end

    end


end


