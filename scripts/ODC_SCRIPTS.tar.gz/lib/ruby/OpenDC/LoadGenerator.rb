#!/usr/bin/ruby
#

#require 'thread'
require 'observer'

module OpenDC

    class LoadGenerator


        class LoadHelper <
            Struct.new(:online_ref,:status,:sum_costs)
        end

        def initialize(greedy_search,shelpers)
            @greedy_search=greedy_search
            @search_helpers = shelpers
            @threads = Hash.new

            # All threads are stopped
            @freeze = ConditionVariable.new

            # Each VM is assigned an online refinement instance.
            @load_helpers=Hash.new

            @lhelper_mutex=Mutex.new
            @lhelper_res=ConditionVariable.new
            @shelper_mutex=Mutex.new



            @search_helpers.each{|key,hp|

                # Initialize load helpers based on the information from search helpers.
                @load_helpers[key] = LoadHelper.new
                @load_helpers[key].online_ref=OnlineRefinement.new(hp.cost_estimator)
                @load_helpers[key].status=(REFINEMENT_ENABLED)?OnlineRefinement::STATES[:on]:OnlineRefinement::STATES[:off]
                @load_helpers[key].sum_costs=0
            }

            if DYNAMIC_CONFIGURATION_MANAGEMENT
                @dcm=DynamicConfigurationManagement.new(self)
                @dcm_mutex=Mutex.new
                @enable_dcm=nil
                @dcm.add_observer(self)
            end

        end

        def run

            OpenDC.log "Starting to run the workloads."
            # For each helper, lauch one execution thread
            @load_helpers.each{|vm_id,lhp|

                @threads[vm_id] = Thread.new {

                    hp=nil
                    @shelper_mutex.synchronize {
                        hp = @search_helpers[vm_id]
                    }

                    next_workload = hp.workload_array.shift
                    total_cost = 0
                    @finish_refinement=false
                    @finish_ref_mutex=Mutex.new
                    while next_workload

                        OpenDC.log "Load Generator: --- Running workload for VM #{vm_id} ---"
                        new_cost = hp.db_helper.wk.calculate_cost(next_workload,true)
                        lhp.sum_costs+=new_cost
                        OpenDC.log "Load Generator: --- Workload has been run for VM #{vm_id}. There (is/are) #{hp.workload_array.size} left. ---"


                        # Check whether the cost refinement is still necessary
                        skip_refinement=false
                        @finish_ref_mutex.synchronize{
                            skip_refinement=@finish_refinement
                        }


                        if REFINEMENT_ENABLED and !skip_refinement


                            OpenDC.log "Load Generator: --- Starting to run the Online Refinement for VM #{vm_id} ---"
                            hp.cost_estimator=lhp.online_ref.update(hp.current[:allocation],new_cost)
                            OpenDC.log "Load Generator: --- VM #{vm_id} had its cost model updated ---"


                            @lhelper_mutex.synchronize {

                                # Check if no longer need to refine the costs.
                                if lhp.status != OnlineRefinement::STATES[:off]
                                    OpenDC.log "Load Generator: VM #{vm_id} is ready for a new search."
                                    lhp.status=OnlineRefinement::STATES[:search]

                                    # Wait for this resource to become available.
 #                                   @lhelper_res.wait(@lhelper_mutex)

                                    not_ready = @load_helpers.detect {|key,lhelper|  lhelper.status != OnlineRefinement::STATES[:search]}

                                    # Check if all workloads are ready to have a new search to be run.
                                    unless not_ready

                                        OpenDC.log "Load Generator: All VMs are ready for a new search."
                                        @shelper_mutex.synchronize{
                                            old_helpers = @search_helpers
                                            @search_helpers = @greedy_search.run(@search_helpers)
#                                            if DYNAMIC_CONFIGURATION_MANAGEMENT and @dcm

#                                                @search_helpers.each{|key,hp| @dcm.update_estimator(key,hp.cost_estimator)}
#                                            end
                                            # If new allocation does not change from the differ from the last one, stop refining costs.
                                            unless different_helpers_allocations(@search_helpers,old_helpers)
                                                @finish_ref_mutex.synchronize {
                                                    @finish_refinement = true
                                                }
                                                @load_helpers.each{|key,lhelper| lhelper.status = OnlineRefinement::STATES[:off]}
                                            end
                                        }
                                        OpenDC.log "Load Generator: Cost models were updated."

                                        if DYNAMIC_CONFIGURATION_MANAGEMENT and @enable_dcm.nil?
                                            @dcm_mutex.synchronize {
                                                # The resource can be released
    #                                            @lhelper_res.signal
                                                @enable_dcm=true
                                                OpenDC.log "Load Generator: Enabling Dynamic Configuration Management"
                                            }
                                        end

                                    end
                                else
                                    OpenDC.log "Load Generator: New search is not needed for VM #{vm_id}"
                                end


                            }
                        end



                        total_cost+=new_cost
                        OpenDC.log "VM #{hp.vm.id} had another part of the workload processed. Partial cost: #{total_cost}"

                        next_workload = hp.workload_array.shift
                    end

                    if DYNAMIC_CONFIGURATION_MANAGEMENT and @enable_dcm
                        @dcm_mutex.synchronize {
                             @enable_dcm=false
                             OpenDC.log "Load Generator: Disabling Dynamic Configuration Management"
                        }
                    end

                    OpenDC.log "Total cost of workload for  VM #{vm_id}: #{total_cost}."

                }

            }

            @threads.each{|vm_id,el|
                el.join
            }
            if DYNAMIC_CONFIGURATION_MANAGEMENT and @enable_dcm
                   @dcm_mutex.synchronize {
                       @dcm.enabled=false
                       OpenDC.log "Load Generator: Disabling Dynamic Configuration Management"
                    }
            end


            OpenDC.log "All workloads have been run."
            log_message="Load Generator: Logging costs:\n"
            total=0
            @load_helpers.each{|vm_id,lhp|
                log_message<<"\tCost for VM #{vm_id} = #{lhp.sum_costs}\n"
                total+=lhp.sum_costs
            }
            log_message<<"\tTotal = #{total}"
            OpenDC.log log_message



        end


        # Observer's update method. Called by DynamicConfigurationManagement notify_observers
        def update(restart_search)
            if restart_search

                OpenDC.log "Load Generator: Cost model full update. Discarding old cost models."
                @search_helpers=@greedy_search.run(@search_helpers,false)
                @search_helpers.each{|key,hp|
                    @dcm.update_estimator(key,hp.cost_estimator)
                }
                @finish_ref_mutex.synchronize {
                    @finish_refinement=false
                }
            end
        end

        def load_snapshot

            unless @enable_dcm
                return nil
            end

            result = []

            @search_helpers.each{|vm_id,hp|
                if hp.workload_array.size == 0
                    return nil
                end
                res_vm=[]
                res_vm[0]=vm_id
                res_vm[1]=hp.db_helper.wk.history_average
                res_vm[2]=hp.cost_estimator.query_estimative_history

                if !res_vm[1] or !res_vm[2]
                    return nil
                end

                result<<res_vm
            }

            #puts result.inspect
            result

        end

        private

        def different_helpers_allocations(hps1,hps2)

            hps1.detect {|key,hp|  !( hp.equal_allocation? hps2[key] )  }
        end



    end
end
