#!/usr/bin/ruby



module OpenDC

    class OnlineRefinement

        STATES = {
            :on => "ON",
            :off => "OFF",
            :search => "SEARCH"
        }

        def initialize(cost_estimator)
            history_points = cost_estimator.history_points

            @cost_model = LinearRegression.new(history_points[:dx],history_points[:dy])

            @cost_estimator=cost_estimator

            @cost_estimator.cost_regression=@cost_model

        end

        # Returns an updated cost estimator  with actual run costs.
        def update(allocation,actual_cost)

            estimated = @cost_model.predict( @cost_estimator.ratio(allocation) )

            update_value = actual_cost / estimated
            OpenDC.log "Online Refinement: Updating cost model:
            \tEstimated cost: #{estimated}
            \tActual cost: #{actual_cost}
            \tUpdating to #{update_value}"

            @cost_model.adjust(update_value)
            @cost_estimator.cost_regression=@cost_model

            @cost_estimator

        end




    end

end
