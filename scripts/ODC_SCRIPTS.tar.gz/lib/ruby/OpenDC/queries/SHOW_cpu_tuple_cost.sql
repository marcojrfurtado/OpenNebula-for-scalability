SHOW cpu_tuple_cost;
