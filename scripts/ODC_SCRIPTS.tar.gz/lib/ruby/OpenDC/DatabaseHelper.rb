

# Database Façade
#

# To use PostgreSQL, just include the following:
# require 'databases/PostgreSQL'


module OpenDC

    include PostgreSQL


    class DatabaseHelper



        attr_accessor :qp, :client, :wk, :ps
        attr_reader :vm_id

#        def initialize( hostaddr, port, dbname, dbuser, dbpassword)
         def initialize( vm, port, dbname, dbuser, dbpassword )
#            @conn = Postgresql.connect(hostaddr, port, dbname, dbuser, dbpassword)
            if ( vm.nil? )
                return
            end
            @vm_id = vm.id
            start_client(vm,port, dbname, dbuser, dbpassword)
            @qp= QueryProcessorHelper.new(@client,@hid)
            @ps= ParameterSetter.new @client
            @wk= WorkloadProcessorHelper.new(@qp)

        end

        def start_client(vm,port,dbname,dbuser,dbpassword)
            @hid = vm['/VM/HISTORY_RECORDS/HISTORY[last()]/HID']
            @vm_ip = vm["/VM/TEMPLATE/NIC/IP"]

            @client = DBClient.new(@vm_ip,port, dbname, dbuser, dbpassword )
        end



    end
end
