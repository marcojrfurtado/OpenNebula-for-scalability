
#!/usr/bin/ruby
module OpenDC


    class CostEstimator

        include PostgreSQL::PostgreSQLCalibration

        attr_accessor :total_allocation, :history, :cost_regression
        attr_reader :query_estimative_history

        def initialize(host,total_allocation=nil)
            @total_allocation = total_allocation
            @host=host
            @dbhelper=nil

            @history=false


            @history_points=Hash.new
            @history_points[:dx]=Array.new
            @history_points[:dy]=Array.new

            start_linear_models

            @cost_regression=nil

            @query_estimative_history=nil
        end


        def start_linear_models

            @cost_models=[]
            calibration_parameters.each{ |parameter|

                file = VMDIR + "/calibration_results/" + @host.id.to_s + "/" + parameter + ".dat"

                @cost_models << LinearRegression.new(file,nil,parameter)

            }
        end

        def estimate(workload,allocation,dbhelper=nil,reset_after=true)
            @dbhelper||=dbhelper

            if @dbhelper.nil?
                message = "No Database helper defined."
                OpenDC.log_error message
                raise Error.new message
            end

            if allocation > @total_allocation
                message =  "Wrong allocation passed to CostEstimator."
                OpenDC.log_error message
                raise OpenDC::Error.new message
            end

            ratio_val=ratio(allocation)
#            puts "#{allocation} : #{ratio_val}"
#            puts "#{allocation} : #{@total_allocation}"
            log_message= "VM #{@dbhelper.vm_id}: Estimating cost with a ratio of #{ratio_val}.\n"


            # If we have defined the linear regression for the cost, then we'll use it. Otherwise, use the DBMS cost estimator.
            if( @cost_regression )
                estimated_cost = @cost_regression.predict ratio_val
                workload_size=@dbhelper.wk.split_workload(workload).size
                @query_estimative_history=estimated_cost/workload_size
                #puts "est:#{estimated_cost}, work_size:#{workload_size}"
            else

                if ( set_parameters(ratio_val,log_message) < 0 )
                    reset_parameters(log_message) if reset_after
                    OpenDC.log log_message
                    return -1
                end


                estimated_cost = @dbhelper.wk.calculate_cost(workload)

                reset_parameters(log_message) if reset_after
            end

            if ( @history )

                @history_points[:dx]<<ratio_val
                @history_points[:dy]<<estimated_cost

            end

            log_message<<"\tESTIMATED COST: #{estimated_cost}\n"


            OpenDC.log log_message

            estimated_cost
        end

        def ratio(allocation)
            (allocation.to_f/@total_allocation)
        end


        def set_parameters(ratio,log_message=nil)

            @cost_models.each{|model|
                calibrated_value = model.predict ratio
                if calibrated_value < 0
                    OpenDC.log_error "Found a negative value for parameter #{model.parameter_name}"
                    return -1
                end
                @dbhelper.ps.set( model.parameter_name, calibrated_value)
                log_message<<"\t#{model.parameter_name} set to #{calibrated_value}\n" if log_message
            }
            return 1
        end


        def reset_parameters(log_message)

           @cost_models.each{|model|
               @dbhelper.ps.reset model.parameter_name
               log_message<<"\t#{model.parameter_name} reset.\n"
            }

        end

        def history_points
            if @history
                return @history_points
            end
            nil
        end

        def clear_history
            if @history
                @history_points=Hash.new
            end
        end


    end
end
