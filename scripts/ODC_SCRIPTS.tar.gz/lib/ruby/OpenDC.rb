# -------------------------------------------------------------------------- #
# Copyright 2002-2012, OpenNebula Project Leads (OpenNebula.org)             #
#                                                                            #
# Licensed under the Apache License, Version 2.0 (the "License"); you may    #
# not use this file except in compliance with the License. You may obtain    #
# a copy of the License at                                                   #
#                                                                            #
# http://www.apache.org/licenses/LICENSE-2.0                                 #
#                                                                            #
# Unless required by applicable law or agreed to in writing, software        #
# distributed under the License is distributed on an "AS IS" BASIS,          #
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   #
# See the License for the specific language governing permissions and        #
# limitations under the License.                                             #
#--------------------------------------------------------------------------- #


begin # require 'rubygems'
    require 'rubygems'
rescue Exception
end

require 'extensions/kernel'
require 'thread'

# Include all supported databases here
require 'OpenDC/databases/PostgreSQL'



require 'OpenDC/DatabaseHelper'
require 'OpenDC/CostEstimator'


require 'OpenDC/CPULimitation'
require 'OpenDC/DiskLimitation'
require 'OpenDC/LinearRegression'
require 'OpenDC/GreedyConfigurationEnumeration'
require 'OpenDC/OnlineRefinement'
require 'OpenDC/LoadGenerator'
require 'OpenDC/DynamicConfigurationManagement'
require 'CommandManager'
require 'BackgroundCommandManager'

require 'OpenNebula'
include OpenNebula

module OpenDC

    Thread.abort_on_exception= true

    ONE_LOCATION=ENV["ONE_LOCATION"]

    if !ONE_LOCATION
        OPENDC_LOCATION = "/var/lib/ruby/OpenDC"
        OPENDC_LOG_LOCATION = "/var/odc.log"
        RUBY_LIB_LOCATION="/usr/lib/one/ruby"
        VMDIR="/var/lib/one"
    else
        OPENDC_LOCATION = ONE_LOCATION + "/lib/ruby/OpenDC"
        OPENDC_LOG_LOCATION = ONE_LOCATION + "/var/odc.log"
        RUBY_LIB_LOCATION=ONE_LOCATION+"/lib/ruby"
        VMDIR=ONE_LOCATION+"/var"
    end

    # Enable the greedy search or use default values.
    SEARCH_ENABLED=true
    # Enable the online refinement.
    REFINEMENT_ENABLED=true
    # Enable the dynamic workload change detector
    DYNAMIC_CONFIGURATION_MANAGEMENT=true

    class SearchHelper <
           Struct.new(:vm,:db_helper, :workload_array, :current, :cost_estimator)


           def equal_allocation?(helper)
               self.current[:allocation] == helper.current[:allocation]
           end
    end

    class WorkloadCredentials <
        Struct::new(:vm_id,:username,:userpassword,:dbname,:workload_array)


        # Pack this object into a byte sequence to be transmitted through a socket.
        def pack
            [ vm_id, username, userpassword, dbname, workload_array.size, workload_array  ].flatten(1).pack("iZ*Z*Z*i#{ 'Z*' * workload_array.size  }")
        end

        # Decode string into WorkloadCredentials parameters
        def unpack(string)
            array = string.unpack("iZ*Z*Z*i")
            n_workloads = array.last.to_i
            array = string.unpack("iZ*Z*Z*i#{ 'Z*' * n_workloads}")

            self.vm_id = array.slice!(0).to_i
            self.username = array.slice!(0)
            self.userpassword = array.slice!(0)
            self.dbname = array.slice!(0)
            array.slice!(0)
            self.workload_array = array
#            puts workload_array.inspect
            if !workload_array.is_a? Array
                message = "Error decoding workload credentials"
                OpenDC.log_error message
                puts message
                raise Error.new message
            end

        end

        def print

            str = ""
            str<<"vm_id: #{vm_id}\n"
            str<<"username: #{username}\n"
            str<<"userpassword: #{userpassword}\n"
            str<<"dbname: #{dbname}\n"
            str<<"Number of workloads: #{workload_array.size}\n"

            workload_array.each_with_index{|el,index|
                str<<"------------ Workload #{index} --------------------\n"
                str<< el + "\n"
                str<<"---------------------------------------------------\n"
            }
            str
        end
    end

    # The Error Class represents a generic error in the OpenDCLibrary
    # library. It contains a readable representation of the error.
    # Any function in the OpenNebula module will return an Error
    # object in case of error.
    class Error < StandardError
        ENO_EXISTS      = 0x0400
        ENOTDEFINED     = 0x1111

        attr_reader :message, :errno

        # +message+ Description of the error
        # +errno+   OpenNebula code error
        def initialize(message=nil, errno=0x1111)
            @message = message
            @errno   = errno
        end

        def to_str()
            @message
        end
    end

    def self.get_host_id(vm)
        hid = vm['/VM/HISTORY_RECORDS/HISTORY[last()]/HID']
    end

    def self.get_vms_ids(vpool,hid)

            vms_ids = vpool.retrieve_elements("/VM_POOL/VM[STATE=3 and LCM_STATE=3]/HISTORY_RECORDS/HISTORY[HID=#{hid} and last()]/../../ID")


    end

    def self.is_vm_active_and_running?(vm)

        OpenNebula::VirtualMachine::VM_STATE[vm.state] == 'ACTIVE' and  OpenNebula::VirtualMachine::LCM_STATE[vm.lcm_state] == 'RUNNING'

    end


    # Returns true if the object returned by a method of the OpenDC
    # library is an Error
    def self.is_error?(value)
        value.class==OpenDC::Error
    end

    # Simple log methods
    #
    def self.log(message)
        fp = File.new(OPENDC_LOG_LOCATION,"a")
        fp.puts("[#{Time.now}]  [EVENT] "+message)
        fp.close
    end

    def self.log_error(message)
        fp = File.new(OPENDC_LOG_LOCATION,"a")
        fp.puts("[#{Time.now}]  [ERROR] "+message)
        fp.close
    end

end
