
#!/usr/bin/env ruby

####################################################
# Script to implement host database calibration
####################################################

ONE_LOCATION=ENV["ONE_LOCATION"]

DEPLOY_TIMEOUT=40
DB_TIMEOUT=15
DEPLOY_CHECK=25
DB_CHECK=8

# Calibration Database
CL_PORT=5432
CL_DBNAME="calibration"
CL_USER="calibrate"
CL_PASSWORD="calibrate"


if !ONE_LOCATION
    RUBY_LIB_LOCATION="/usr/lib/one/ruby"
    VMDIR="/var/lib/one"
else
    RUBY_LIB_LOCATION=ONE_LOCATION+"/lib/ruby"
    VMDIR=ONE_LOCATION+"/var"
end

$: << RUBY_LIB_LOCATION

require 'OpenNebula'
include OpenNebula

require 'OpenDC'
include OpenDC

if !(host_id=ARGV[0])
    puts "No host informed"
    exit -1
end

begin
    client = Client.new()
rescue Exception => e
    puts "Error: #{e}"
    exit -1
end

# Retrieve hostname
host  =  OpenNebula::Host.new_with_id(host_id, client)
exit -1 if OpenNebula.is_error?(host)
host.info
host_name = host.name


# Check wheteher there is already a Calibration VM to be used
#
vm = VirtualMachine.new_with_id(214,client)
exit -1 if OpenNebula.is_error?(vm)

vm.info




# Connect to the PostgreSQ service
att = 1
db_helper = nil
while ( db_helper.nil? )
    begin
        db_helper = DatabaseHelper.new( vm, CL_PORT, CL_DBNAME, CL_USER, CL_PASSWORD  )
    rescue Exception => e
        if ( att < DB_CHECK)
            att+=1
        else
            puts e.message
            puts "Wasn\'t able to connect to the PostgreSQL inside the VM after #{att} attempts. Check Network Configurations."
            exit -1
        end
    end
end

# Start executing queries at different resource levels
#
# First, let's create a file to store these results to be used later.


dest_dir = VMDIR + "/" + "calibration_results" + "/" + host.id.to_s

unless FileTest::directory? dest_dir
    begin
        Dir::mkdir(dest_dir)
    rescue Exception => e
        puts e.message
        puts "Was not able to create the calibration results directory."
        exit -1
    end
end

############### SEQ_PAGE_SCAN ##################
# Get an estimative of seq_page_scan
fp = File.new(dest_dir+"/"+"seq_page_scan.dat","w")
fp.truncate(0)


OpenDC::DiskLimitation.set_concurrent_workers(host,50)

result_set=0.0
(1..3).each {
    result_set = db_helper.client.run_query_file('./queries/seq_page_scan_value.sql')
}
time_seq_scan = result_set.first["get_seq_page_scan"].to_f
fp.puts result_set.first["get_seq_page_scan"]
fp.close

OpenDC::DiskLimitation.end_concurrent_workers(host)

########################################

##### CPU_TUPLE_COST AND CPU_OPERATOR_COST #####

fp_op = File.new(dest_dir+"/"+"cpu_operator_cost.dat","w")
fp_tp = File.new(dest_dir+"/cpu_tuple_cost.dat","w")

fp_tp.truncate(0)
fp_op.truncate(0)

ratio = 0.2
x = Array.new
y = Array.new

result_set = db_helper.qp.process_file('./queries/aggregate_seq_scan.sql')
while ratio < 0.8
    begin
        OpenDC::CPULimitation.set_hardlimit(vm,host,ratio)
    rescue Error => e
        puts e.message
        exit -1
    end

    sleep 0.5

    for i in 1..5 do
        result_set = db_helper.qp.process_file('./queries/aggregate_seq_scan.sql')

        agg = result_set[0]
        seq = result_set[1]

        # The second result constains the SEQ_SCAN, in which the cost is expressed as "num_pages + cpu_tuple_cost * rows"
        # The first contains the AGGREGATE, as the page scans has already been calculated in the SEQ_SCAN, we express this aggregate as follows:
        # "cpu_operator_cost * num_rows - SEQ_SCAN"
        #
        # We collect all the points and perform a linear regression.
        #

        cpu_operator_cost = ( (agg.actual_total_cost - seq.actual_total_cost)/seq.rows ) /  time_seq_scan
        cpu_tuple_cost = ( seq.actual_total_cost/seq.rows ) / time_seq_scan

    #    x << ratio
    #    y << cpu_operator_cost
        #



        fp_op.puts "#{ratio} #{cpu_operator_cost}"
        fp_tp.puts "#{ratio} #{cpu_tuple_cost}"
    end

    ratio+=0.1
end

fp_op.close
fp_tp.close

begin
      OpenDC::CPULimitation.set_hardlimit(vm,host,-1)
rescue Error => e
      puts e.message
      exit -1
end

##################################################







exit 0
