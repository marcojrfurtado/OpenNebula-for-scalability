SELECT * FROM get_seq_page_scan();
