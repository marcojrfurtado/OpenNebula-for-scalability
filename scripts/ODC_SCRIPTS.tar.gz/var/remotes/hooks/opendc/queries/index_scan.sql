EXPLAIN (ANALYZE,BUFFERS) SELECT pa.abalance
	FROM pgbench_accounts AS pa
	WHERE pa.aid > 100
	LIMIT 2000;
