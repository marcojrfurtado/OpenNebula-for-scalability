SELECT max(abalance) FROM pgbench_accounts;
