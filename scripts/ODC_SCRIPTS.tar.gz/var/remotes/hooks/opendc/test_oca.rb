    #!/usr/bin/env ruby

    ####################################################
    # Script to implement host database calibration
    ####################################################

    ONE_LOCATION=ENV["ONE_LOCATION"]

    DEPLOY_TIMEOUT=15
    DB_TIMEOUT=10
    DEPLOY_CHECK=DB_CHECK=4

    if !ONE_LOCATION
        RUBY_LIB_LOCATION="/usr/lib/one/ruby"
        VMDIR="/var/lib/one"
    else
        RUBY_LIB_LOCATION=ONE_LOCATION+"/lib/ruby"
        VMDIR=ONE_LOCATION+"/var"
    end

    $: << RUBY_LIB_LOCATION

    require 'OpenNebula'
    include OpenNebula

    require 'OpenDC'
    include OpenDC

    client = OpenNebula::Client.new

    host  =  OpenNebula::Host.new_with_id(1, client)
    host.info

    puts vm_ids.size




exit 0
